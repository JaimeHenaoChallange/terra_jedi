import boto3
import json
import base64

def encrypt(data, cmk_id):
    kms = boto3.client('kms')
    response = kms.encrypt(
        KeyId=cmk_id,
        Plaintext=json.dumps(data).encode()
    )
    return base64.b64encode(response['CiphertextBlob']).decode()

def decrypt(encrypted_data, cmk_id):
    kms = boto3.client('kms')
    decrypted = kms.decrypt(
        KeyId=cmk_id,
        CiphertextBlob=base64.b64decode(encrypted_data)
    )
    return json.loads(decrypted['Plaintext'])

def lambda_handler(event, context):
    # Retrieve and decrypt the Jedi Manifest
    encrypted_manifest = event['Records'][0]['s3']['object']['key']
    decrypted_manifest = decrypt(encrypted_manifest, os.environ['CMK_ID'])
    jedi_id = context.function_name.split('-')[-1]

    # Process the Jedi information and update the location
    updated_jedi_location = process_jedi_location(decrypted_manifest, jedi_id)

    # Encrypt and store the updated Jedi information
    encrypted_jedi_info = encrypt(updated_jedi_location, os.environ['CMK_ID'])
    store_encrypted_jedi_info(encrypted_jedi_info, os.environ['JEDI_MANIFEST_BUCKET'])
